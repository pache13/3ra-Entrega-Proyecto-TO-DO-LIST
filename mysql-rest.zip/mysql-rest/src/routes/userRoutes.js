const User= require('../models/user');
const path=require('path');
module.exports= function (app) {

	app.get('/users', (req, res) => {

		User.getUsers((err,data)=>{
			
          res.status(200).json(data);

		});
    

	});

	app.post('/users',(req, res)=>{
        const userData = {
         id:null,
         nombre:req.body.nombre,
         descripcion: req.body.descripcion,
         fecha:req.body.fecha,
         prioridad:req.body.prioridad,
         estado:req.body.estado

        };
      User.insertUser(userData,(err, data)=>{
      	if (data && data.insertId){
      		res.json({
      			success:true,
      			msg:'Nota Agregada',
      			data: data
      		})
      	} else {
      		res.status(500).json({
      			success:false,
      			msg:'Error'
      		})
      	}
      }) 
	});
	
	 app.put('/users/:nombre',(req,res)=>{
 
         const userData = {
         id:null,
         nombre:req.params.nombre,
         descripcion: req.body.descripcion,
         fecha:req.body.fecha,
         prioridad:req.body.prioridad,
         estado:req.body.estado	
         };

         User.updateUser(userData , (err,data)=>{
         	if (data && data.msg){
            res.json(data)
         	} else {
         		res.json({
         			success: false,
         			msg:'error'
         		})
         	}
         })
    });


app.delete('/users/:nombre',(req,res)=>{
  User.deleteUser(req.params.nombre,(err, data)=>{
    if (data && data.msg ==='Eliminado' || data.msg==='No existe'){
    	res.json({
    		success:true,
    		data
    	})
    }else{
    	res.status(500).json({
    		msg:'Error'
    	})
    }
  });
});


}



