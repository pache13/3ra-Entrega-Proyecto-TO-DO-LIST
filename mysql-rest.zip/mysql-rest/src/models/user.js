const mysql = require('mysql');

connection = mysql.createConnection({

host:'localhost',
user:'root',
password:'',
database:'basenotas'
});

let userModel= {};

userModel.getUsers = (callback) => {

if (connection){
connection.query('SELECT * FROM notas',(err, rows)=>{
      if (err){
      	throw err;
      }

      else {
      	callback(null, rows);
      }

     } 

	)
 };

};


userModel.insertUser = (userData , callback)=>{

	if (connection){
		connection.query(
           'INSERT INTO notas SET ?',userData,
           (err, result)=>{
           	  if(err){
           		throw err;
           	      } else {
           		callback(null,{
           			'insertId': result.insertId
           		})
           	  }
           }
			)
	}
};


userModel.updateUser = (userData, callback)=> {
     if (connection){
       
      const sql = 'UPDATE notas SET n_nombre = ${connection.escape(userData.nombre)},n_descripcion=${connection.escape(userData.descripcion)},n_fecha=${connection.escape(userData.fecha)},n_prioridad= ${connection.escape(userData.prioridad)},n_estado= ${connection.escape(userData.estado)} WHERE n_nombre=${connection.scape(userData.nombre)}';
      
      connection.query(sql,(err, result)=>{
       if (err){
       	throw err;
       } else {
         callback(null,{
          "msg":"success"
         });

        }
      })

     }

};



userModel.deleteUser = (nombre,callback)=>{

if (connection){
	let sql='SELECT FROM notas WHERE n_nombre=${connection.escape(nombre)}';
	connection.query(sql,(err,row)=>{
		if (row){
			let sql='DELETE FROM notas WHERE n_nombre=${nombre}';
			connection.query(sql,(err,result)=>{
				if(err){
					throw err
				}else {
					callback(null,{
						msg:'Eliminado'
					})
				}
			})
		}else{
          callback(null,{
          	msg:'No existe'
          })
		}
	});
 }
};
module.exports=userModel;