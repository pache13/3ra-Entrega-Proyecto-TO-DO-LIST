CREATE DATABASE basenotas;

USE basenotas;

CREATE TABLE IF NOT EXISTS 'notas' (

'n_id'  INT(11)  NOT NULL AUTO_INCREMENT,
'n_nombre' VARCHAR(100) COLLATE latin1_swedish_ci NOT NULL,
'n_descripcion' VARCHAR(100) COLLATE latin1_swedish_ci NOT NULL,
'n_fecha' VARCHAR(100) COLLATE latin1_swedish_ci NOT NULL,
'n_prioridad' INT(11)  NOT NULL ,
'n_estado' VARCHAR(100) COLLATE latin1_swedish_ci NOT NULL,
PRIMARY KEY ('n_id')
);

DESCRIBE notas;