
          
<html>
    <head>
        <meta charset="UTF-8">
        <title>Nueva Tarea</title>
        <link href="Css/Styles/CssPrincipal.css" rel="stylesheet" type="text/css">
         <style type="text/css">
        html, body {
        height: 100%;
        width: 100%;
        padding: 0;
        margin: 0;
        }
 
       #full-screen-background-image {
        z-index: -999;
        width

: 100%;
        height: auto;
        position: fixed;
        top: 0;
        left: 0;
        }
        </style>
    </head>
    <body>
         <img alt="full screen background image" src="Css/images/hoja1.jpg" id="full-screen-background-image"/>
          <center>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>

        <form method="post" action="guardar.php" >
           <table>
        	
        	<tr>
        		<td><p><h3><font color="white">Nombre de la Nota:</font></h3></p></td>
        		<td><input type="text" REQUIRED name="nombre"></td>
        	</tr>
        	<tr>
        		<td><p><h3><font color="white">Descripcion:</font></h3></p></td>
        		<td><input type="text" REQUIRED name="descripcion"></td>
        	</tr>
        	<tr>
        		<td><p><h3><font color="white"> Fecha:</font></h3></p></td>
        		<td><input type="date" REQUIERED name="fecha"></td>
        	</tr>
        	<tr>
        		<td><p><h3><font color="white"> Prioridad:</font></h3></p></td>
        		<td>
            <select REQUIRED name="prioridad">
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>  
            </select>  
            </td>
        	</tr>
        	<tr>
        		<td><p><h3><font color="white"> Estado:</font></h3></p></td>
        		<td><input type="text" REQUIRED name="estado" value="Pendiente" readonly="readonly"><br><br></td>
        	</tr>
        	<tr>
        		<td></td>
        		<td><button class="button button5">Agregar</button></td>

        	</tr>

        </table>
        
        	</form>
            </center>
           </body>
</html>