<?php

 $conexion=mysql_connect("localhost","root","");
 mysql_select_db("basenotas",$conexion);
 
 $nom=$_REQUEST['nombre'];
 $nombre=$_POST['nombre'];
 $descrip=$_POST['descripcion'];
 $fech=$_POST['fecha'];
 $prio=$_POST['prioridad'];
 $est=$_POST['estado'];

 mysql_query("UPDATE notas SET n_nombre='$nombre',n_descripcion='$descrip',n_fecha='$fech',n_prioridad='$prio',n_estado='$est' WHERE n_nombre='$nom'",$conexion);

 header("Location: pagina.php");

?>