<?php

 $conexion=mysql_connect("localhost","root","");
 mysql_select_db("basenotas",$conexion);

 $nom=$_REQUEST['nombre'];
 
 mysql_query("DELETE FROM notas WHERE n_nombre='$nom'",$conexion);

 header("Location: pagina.php");

?>