<?php

           $con=mysql_connect("localhost","root","");
           mysql_select_db("basenotas",$con);
          
           ?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>To Do List</title>
        <link href="Css/Styles/CssPrincipal.css" rel="stylesheet" type="text/css">
       
        <style type="text/css">
        .button {
   background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 16px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    -webkit-transition-duration: 0.4s; /* Safari */
    transition-duration: 0.4s;
    cursor: pointer;
}
.button5 {
    background-color: white;
    color: black;
    border: 2px solid #555555;
}

.button5:hover {
    background-color: #555555;
    color: white;
}
    html, body {
        height: 100%;
        width: 100%;
        padding: 0;
        margin: 0;
        background-attachment: scroll;
        }
 
       #full-screen-background-image {
        z-index: -999;
        width

: 100%;
        height: auto;
        position: fixed;
        top: 0;
        left: 0;

        }
        </style>
    </head>
    <body>  
      <img alt="full screen background image" src="Css/images/hoja1.jpg" id="full-screen-background-image" />

       
       
        <center>
          <h1><font color="white"> To Do List</font></h1>
          <br>
          <br>
          <br>
          
        <table>
             <tr>
               <th colspan="1"><a href="formulario.php"><button class="button button5">Agregar Nota</button></a></th>
             </tr>
           </table>

           <br>
           <br>

           <h2><font color="white"> Tareas Pendientes </font></h2>

           <table  border="1">
        	
        	<thead>
                <tr>
                    
                    <th colspan="7"><h4><font color="white"> Lista de Tareas</font></h4></th> 
                </tr>
               </thead>
            <tbody>

                <tr>
                    <td><b><h4><font color="white"> Nombre</font></h4></b></td>
                    <td><b><h4><font color="white">Descripcion</font></h4></b></td>
                    <td><b><h4><font color="white"> Fecha</font></h4></b></td>
                    <td><b><h4><font color="white"> Prioridad</font></h4></b></td>
                    <td><b><h4><font color="white"> Estado </font></h4></b></td>
                    
                </tr>

                 <?php
                  $query="SELECT * FROM notas WHERE n_estado='Pendiente'";
                  $resultado=mysql_query($query,$con);
              while ($registrodatos=mysql_fetch_array($resultado))
              {
                ?>

              <tr>
                  <td width="100" align="center"><h4><font color="white"> <?php echo $registrodatos['n_nombre']?></font></h4></td>
                  <td width="100" align="center"><h4><font color="white"> <?php echo $registrodatos['n_descripcion']?></font></h4></td>
                  <td width="100" align="center"><h4><font color="white"> <?php echo $registrodatos['n_fecha']?></font></h4></td>
                  <td width="100" align="center"><h4><font color="white"> <?php echo $registrodatos['n_prioridad']?></font></h4></td>
                  <td width="100" align="center"><h4><font color="white"> <?php echo $registrodatos['n_estado']?></font></h4></td>
                  <td width="100" align="center"><a href="modificar.php?nombre=<?php echo $registrodatos['n_nombre']; ?> " ><font color="white"><h4><font color="white"> Modificar</font></h4></font></a></td>
                  <td width="100" align="center"><a href="eliminar.php?nombre=<?php echo $registrodatos['n_nombre']; ?> "><img src="Css/images/Bote_de_basura.png" class="b1" /></a></td>
              </tr>




              <?php

               }

              ?>
              </center>
           </tbody>

        </table>


       <br>
       <br>
       <br>
       <br>

       <h2><font color="white"> Tareas Completadas</font></h2>
       <table  border="3">
          
          <thead>
                <tr>
                    
                    <th colspan="6"><h4><font color="white"> Lista de Tareas</font></h4></th> 
                </tr>
               </thead>
            <tbody>

                <tr>
                    <td><b><h4><font color="white"> Nombre</font></h4></b></td>
                    <td><b><h4><font color="white"> Descripcion</font></h4></b></td>
                    <td><b><h4><font color="white"> Fecha</font></h4></b></td>
                    <td><b><h4><font color="white"> Prioridad</font></h4></b></td>
                    <td><b><h4><font color="white"> Estado<font></font></h4></b></td>
                    
                </tr>

                 <?php
                  $query="SELECT * FROM notas WHERE n_estado='Completado'";
                  $resultado=mysql_query($query,$con);
              while ($registrodatos=mysql_fetch_array($resultado))
              {
                ?>

              <tr>
                  <td width="100" align="center"><h4><font color="white"> <?php echo $registrodatos['n_nombre']?></font></h4></td>
                  <td width="100" align="center"><h4><font color="white"> <?php echo $registrodatos['n_descripcion']?></font></h4></td>
                  <td width="100" align="center"><h4><font color="white"> <?php echo $registrodatos['n_fecha']?></font></h4></td>
                  <td width="100" align="center"><h4><font color="white"> <?php echo $registrodatos['n_prioridad']?></font></h4></td>
                  <td width="100" align="center"><h4><font color="white"> <?php echo $registrodatos['n_estado']?></font></h4></td>
                  <td width="100" align="center"><a href="eliminar.php?nombre=<?php echo $registrodatos['n_nombre']; ?> "><img src="Css/images/Bote_de_basura.png" class="b1" /></a></td>
              </tr>




              <?php

               }

              ?>
              </center>
           </tbody>

        </table>



    </body>
</html>