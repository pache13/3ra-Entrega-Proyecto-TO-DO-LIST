
          
<html>
    <head>
        <meta charset="UTF-8">
        <title>Modificar Tarea</title>
        <link href="Css/Styles/CssPrincipal.css" rel="stylesheet" type="text/css">
             <style type="text/css">
    html, body {
        height: 100%;
        width: 100%;
        padding: 0;
        margin: 0;
        }
 
       #full-screen-background-image {
        z-index: -999;
        width

: 100%;
        height: auto;
        position: fixed;
        top: 0;
        left: 0;
        }
        </style>
    </head>
    <body>
        <img alt="full screen background image" src="Css/images/hoja1.jpg" id="full-screen-background-image"/>

          <center>

           <?php
            
            $con=mysql_connect("localhost","root","");
           mysql_select_db("basenotas",$con);
           $nombre=$_REQUEST['nombre'];
           $query="SELECT * FROM notas WHERE n_nombre='$nombre'";
          $resultado=mysql_query($query,$con);
           $registrodatos=mysql_fetch_array($resultado)
              
           
           
           ?>
           <br>
           <br>
           <br>
           <br>
           <br>
           <br>
           <br>
           <br>
           <br>
           <br>
           <br>
           <br>
           <br>



        <form method="post" action="modificar_proceso.php?nombre=<?php echo $registrodatos['n_nombre']; ?> ">

             
           <table>
            <tr>
                <td><p><h3><font color="white">Nombre de la Nota:</font></h3></p></td>
                <td><input type="text" REQUIRED name="nombre" value="<?php echo $registrodatos['n_nombre']; ?>"></td>
            </tr>
        		
        		<tr>
              <td><p><h3><font color="white">Descripcion:</font></h3></p></td>
              <td><input type="text" REQUIRED name="descripcion" value="<?php echo $registrodatos['n_descripcion']; ?>"> </td>      
                </tr>

        		<tr>
              <td><p><h3><font color ="white">Fecha:</h3></p></td>
              <td><input type="date" REQUIERED name="fecha" value="<?php echo $registrodatos['n_fecha']; ?>"></td>      
                </tr>
                
        	    <tr>
                 <td><p><h3><font color="white">Prioridad:</font></h3></p></td>
                 <td>
                   <select REQUIRED name="prioridad" value="<?php echo $registrodatos['n_prioridad']; ?>">
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>  
                    </select>  

                 </td>   
                </tr>
        		
        		<tr>
              <td><p><h3><font color="white">Estado:</font></h3></p></td>
              <td>
                <select REQUIRED name="estado" value="<?php echo $registrodatos['n_estado']; ?>">
                    <option value="Pendiente">Pendiente</option>
                    <option value="Completado">Completado</option>
                      
                    </select>
                </td>      
                </tr>

                <tr>
                    <td></td>
                    <td> <input type="submit" name="btn_agregar" value="Modificar"></td>
                </tr>
        	
         </table>
        	
        	</form>
           
            </center>
           </body>
</html>