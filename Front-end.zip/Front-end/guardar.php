<?php
  
  $conexion=mysql_connect("localhost","root","");
 mysql_select_db("basenotas",$conexion);

 $nombre=$_POST['nombre'];
 $descrip=$_POST['descripcion'];
 $fech=$_POST['fecha'];
 $prio=$_POST['prioridad'];
 $est=$_POST['estado'];

 mysql_query("INSERT INTO notas(n_nombre,n_descripcion,n_fecha,n_prioridad,n_estado)VALUES('$nombre','$descrip','$fech','$prio','$est')",$conexion);

 header("Location: pagina.php");



  ?>










 